#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#define NTRIES  1000

void runcmd(char *cmd){
	int last = strlen(cmd)-1; //quando o comando é "\n" dá erro pois o last fica a -1 
	char *name;
	//if(last<0) printf("comando: enter\n"); //solução do erro da linha anterior
	//else {
		int changeFile = 0; //descomentar se for necessário
		if( cmd[last]=='='){
			*name = cmd[last];
			//eliminar o primeiro caracter ('=')
			for(int i=1; i<strlen(name);i++){
				name[i-1]=name[i];
			}
			
			changeFile =1;
		}
		pid_t pid = fork();
		switch (pid){
			case 0:
				execlp(cmd,cmd,NULL);
				perror(cmd);
				exit(1);
			case -1:
				perror("fork");
				break;
			default:
				//se changeFile == 1 o output é redirecionado para o ficheiro 
				//que tem o nome a seguir
				if(changeFile) {
					close(1);
				//criar o documento de escrita de output caso nao exista já
				if(creat(name, 0666) == -1){
					perror(name);
					exit(1);
				}
				execlp("wc","wc","-l",NULL);
				exit(1);
				}
		}
	//}
}

int do_something(void) { return 1; }

int main(int argc, char *argv[]) {
    int i, p;
    long elapsed;
    struct timeval t1,t2;

    gettimeofday(&t1, NULL);
    for (i = 0;  i < NTRIES; i++){
	//printf("Writing");//fflush(stdout);
    	//p=getuid();
        p = do_something();  // code to evaluate
        }
    gettimeofday(&t2, NULL);
    elapsed = ((long)t2.tv_sec - t1.tv_sec) * 1000000L
            + (t2.tv_usec - t1.tv_usec);
    //runcmd(argv);
    printf("Elapsed time = %li us (%g us/call)\n",
            elapsed, (double)elapsed/NTRIES);
    return 0;
}

