
/**
 * block_queue
 *
 * implementation of a queue of data blocks
 * each block includes the data array and the size of data in this block
 * 
 * before use the queue must be initialized by calling queue_init
 *
 * (c) 2023 - Vitor Duarte FCT UNL
 */

#include <pthread.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "blockqueue.h"


// block of data
typedef struct {
    int size;          // used bytes in data array
    char data[BLKSZ];  // data
} block_t;


block_t *buffer;  // circular buffer 
int maxsize;      // circular buffer size
int used=0;           // buffer slots in use
int pidx=0, gidx= 0;  // put index and get index

#define FULLBUF (used==maxsize)
#define EMPTYBUF (used==0)


void putInBuffer(char *data, int s) {
    assert(used<maxsize);

    memcpy(&(buffer[pidx].data), data, s);
    buffer[pidx].size=s;
    pidx= (pidx+1)%maxsize;
    used++; 
}

int getFromBuffer(char *data) {
    assert(used>0);

    memcpy(data, &(buffer[gidx].data), buffer[gidx].size);
    int tmp=buffer[gidx].size;
    gidx = (gidx+1)%maxsize;
    used--;
    return tmp;
}

/** public functions **/

/**
 * queue_init - initialize queue of data blocks
 * size - max number of blocks
 * return 0 if failed to allocate queue
 */
int queue_init( int size ) {
    buffer = malloc( size*sizeof(block_t) );
    maxsize = size;
    return buffer != NULL;
}


/**
 * queue_put - put one block of data in queue
 * data - pointer to array of bytes
 * sz - array size
 */
void queue_put(void *data, int sz) {  // TODO:
    while (FULLBUF) {
    }
    putInBuffer(data, sz);
}


/**
 * queue_take - get next data block from queue
 * data - pointer to array (at least 1K) where to place the data
 * returns number of bytes placed in data
 */
int queue_take(void *data) {  // TODO:
    while (EMPTYBUF) {
    }
    int tmp = getFromBuffer(data);
    return tmp;
}


