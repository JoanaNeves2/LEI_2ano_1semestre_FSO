/*****
 * FSO DI-FCT/UNL
 * example for Lab 0
 */
 
#include <stdio.h>
#include <stdlib.h>
#define MY_NUMBER	"123"

int main(int argc, char *argv[])
{
    printf("And my number is... %d\n", atoi(MY_NUMBER));
    return 0;
}
