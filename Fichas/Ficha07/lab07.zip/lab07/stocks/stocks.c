
/**
 * stocks
 * 
 * the writer part of a shared memory demo. Just one can run.
 * this will be simulating the publishing of sotcks transactions on a
 * public board (in shared memory).
 * the readers-writer pattern should be used so that we don't write
 * when clients are reading.
 * 
 * 2023 - Vitor Duarte
 * DI - FCT UNL
 */
 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <fcntl.h>

#include "shared_board.h"


#define LSIZE 1000



struct shared_board *board;   // the shared board!



/**
 * create_board - creates shared memory with stocks board and extra variables
 *      needed. Map it to memory.
 *      (also create any other objects for concurrency control)
 */
void create_board() {
    // create and initialize semaphores
    
    // create and initialize shared memory
    //  don't forget ftruncate

    //board = mmap(...)
   
}


/**
 * publish - adds a new transaction to the top of global board
 *      (must shift down table contents and clients should not see 
 *      inconsistent tables)
 */
void publish(int seq, char *comp, float price, int num) {
    // writer lock

    for ( int i=9; i>0; i--) {  // shift down
       board->board[i] = board->board[i-1];
       usleep(1);               // slowlly so data races can easely appear
    }

    strcpy(board->board[0].name, comp);
    board->board[0].seq = seq;
    board->board[0].price = price;
    board->board[0].amount = num;

    // writer unlock
}


/**
 * main - starts by opening a transactions file that will be used to
 *      simulate the operations to put in the public shared board. 
 *      There is only one stocks running and this must be the "owner"
 *      of shared memory and concorrency control objects, so it is
 *      responsable for its creation and initializations.
 */
int main(int argc, char *argv[]) {
    char line[LSIZE];
    int count = 0;
    FILE *trace;
    if ( argc!=2 || (trace = fopen(argv[1], "r"))==NULL ) {
        if (argc==2) perror(argv[1]);
        fprintf(stderr,"usage: %s file\n", argv[0]);
        exit(1);
    }

    create_board();
    
    while ( fgets( line, LSIZE, trace )!=NULL ) { // simulate exchange operations
        char comp[5];
        float price;
        int amount;
        count++;
        sscanf(line, "%s%f%i", comp, &price, &amount);
        printf("adding:  %i: %s $%f %i\n", count, comp, price, amount);
        publish(count, comp, price, amount);
        printf("done.\n\n");
        usleep(200000);
    }
    return 0;
}
